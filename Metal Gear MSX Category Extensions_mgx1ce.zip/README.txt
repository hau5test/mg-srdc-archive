This archive preserves historical speedrun leaderboard data, game leaderboards, and community submissions from Speedrun.com recorded prior to October 1, 2026, at 22:42:00 UTC for a specific game community.

On that date, site operator Elo Entertainment updated the platform's Terms of Use to remove its longstanding Creative Commons license in an effort to restrict data access. Because Creative Commons grants are legally irrevocable (CC-BY-NC 4.0, Section 2.a.1), all submissions and records published prior to that update remain perpetually licensed under CC-BY-NC 4.0.

This data was created, verified, and curated over more than a decade by thousands of community runners and volunteer moderators. It is preserved here under the Creative Commons Attribution-NonCommercial 4.0 International license (see LICENSE) to ensure the history of speedrunning remains permanently open and freely accessible to everyone.
